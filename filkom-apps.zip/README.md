![Logo](/logo.png)

# Filkom Apps
> Untuk sementara hanya akan mendukung pengecekan jadwal kuliah

### Expected features (?)
- Changing between light and dark theme
- Kehadiran dosen
